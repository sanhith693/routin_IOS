//
//  ViewController.swift
//  routin
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            
            //We need to view courses of the logged in student in CourseViewController,
            // So we pass the courses from the 'studentObj' variable
            if transition == "detailRoute" {
                let destination = segue.destination as! PageOneViewController
                
                //we will assign the courses to 'courseArray' in the CourseViewController
                destination.routeText = "Hello from main page"
            }
        }


}

