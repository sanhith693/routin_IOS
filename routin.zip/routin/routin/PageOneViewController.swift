//
//  PageOneViewController.swift
//  routin
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit

class PageOneViewController: UIViewController {

    @IBOutlet weak var mylabel: UILabel!
    
    var routeText: String = ""
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        mylabel.text = routeText

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            
            //We need to view courses of the logged in student in CourseViewController,
            // So we pass the courses from the 'studentObj' variable
            if transition == "routeTwo" {
                let destination = segue.destination as! ThirdViewController
                
                //we will assign the courses to 'courseArray' in the CourseViewController
                destination.c3 = "Hello from first page page"
            }
        }

}
